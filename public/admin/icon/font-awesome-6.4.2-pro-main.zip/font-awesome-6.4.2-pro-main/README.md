# font-awesome-6.4.2-pro

Font Awesome 6.4.2 Pro

[Code Thuần PHP](https://codethuan.com)